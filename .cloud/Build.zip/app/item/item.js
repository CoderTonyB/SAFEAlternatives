"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Item = (function () {
    function Item() {
    }
    return Item;
}());
exports.Item = Item;
