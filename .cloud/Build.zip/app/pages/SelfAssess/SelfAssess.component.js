"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
//import { RouterExtensions } from 'nativescript-angular';
//import { TextField } from 'ui/text-field';
//import { EventData } from 'data/observable';
//import { ActivatedRoute } from '@angular/router';
var data_service_1 = require("../../services/data.service");
var email = require("nativescript-email");
var ModalPicker = require("nativescript-modal-datetimepicker").ModalDatetimepicker;
var SelfAssessComponent = (function () {
    function SelfAssessComponent(dataService) {
        this.dataService = dataService;
        this.Questions = new Array();
    }
    SelfAssessComponent.prototype.ngOnInit = function () {
        setTimeout(function (me) {
            me.dataService.getSelfAssessmentQuestions().then(function (questions) {
                me.Questions = questions;
            }, function (error) { return alert("Error:" + error); });
        }, 1000, this);
    };
    SelfAssessComponent.prototype.sliderChanged = function (value, questionId) {
        //let q = <Slider>event.object;
        this.Questions.find(function (x) { return x.QuestionId == questionId; }).Answer = value;
        //console.log(questionId, "=", q.value);
    };
    SelfAssessComponent.prototype.datepickerChanged = function (event, questionId) {
        var q = event.object;
        //this.Questions.find(x => x.QuestionId == questionId).Answer = q.date;
        console.log(questionId, "=", q.date);
    };
    SelfAssessComponent.prototype.datepickerTapped = function (event, questionId) {
        var q = event.object;
        q.dismissSoftInput();
        var picker = new ModalPicker();
        picker.pickDate({
            title: "Last Self Injury Date",
            theme: "Forest",
            maxDate: new Date()
        }).then(function (result) {
            q.text = +result.month + "/" + result.day + "/" + result.year;
        }).catch(function (error) {
            console.log("Error: " + error);
        });
        //console.log(questionId, "=", q.date);
    };
    SelfAssessComponent.prototype.switchChanged = function (event, questionId) {
        var q = event.object;
        this.Questions.find(function (x) { return x.QuestionId == questionId; }).Answer = q.checked;
        //console.dir(this.Questions);
    };
    SelfAssessComponent.prototype.checkBoolean = function (answer) {
        var lcAnswer = (answer) ? answer.toLowerCase() : 'false'; //make null answers = false
        if (lcAnswer == 'true') {
            return true;
        }
        else {
            return false;
        }
    };
    SelfAssessComponent.prototype.setIntNull = function (intQuestion) {
        if (intQuestion.text == '0') {
            intQuestion.text = '';
        }
    };
    SelfAssessComponent.prototype.getAnswerIndex = function (QuestionId) {
        var index = this.Questions.findIndex(function (x) { return x.QuestionId == QuestionId; });
        return index;
    };
    SelfAssessComponent.prototype.scoreAssessment = function () {
        var q1to14 = this.Questions.filter(function (x) { return x.Order < 15 && x.Answer == true; }).length;
        var q15to23 = this.Questions.filter(function (x) { return x.Order >= 15 && x.Order <= 23 && x.Answer == true; }).length;
        var q24to31 = this.Questions.filter(function (x) { return x.Order >= 24 && x.Order <= 31 && x.Answer == true; }).length;
        var q32to42 = this.Questions.filter(function (x) { return x.Order >= 32 && x.Order <= 42 && x.Answer == true; }).length;
        var mailbody = "\n\t\t<b>1-14</b> (" + q1to14 + " answered true)<br/>The more questions you answered \"true\", the more likely it is that your early experiences were similar to those described by self injurers.<br/><br/>\n<b>15-23</b> (" + q15to23 + " answered true)<br/>The more questions you answered \"true\", the more your view of yourself matches the views commonly expressed by self injurers.<br/><br/>\n<b>24-31</b> (" + q24to31 + " answered true)<br/>If you answered \"true\" to any of these questions, it may signal that you have a serious problem with self-injury.<br/><br/>\n<b>32-44</b> (" + q32to42 + " answered true";
        var numTimesSI = this.Questions.find(function (x) { return x.Order == 43; }).Answer;
        console.log("numtimesi:", numTimesSI);
        if (numTimesSI > 0) {
            mailbody += " and you have indicated that you have self injured at least " + numTimesSI + " times";
        }
        mailbody += ")<br/>We suggest that anyone who answered \"true\" to any of these questions might benefit from consultation with a professional who understands self-injury.  You may use the questionnaire as a tool for discussion during the consultation.<br/><br/>\nFeel free to share this e-mail with anyone who you feel might be able to help you.  <br/><br/>\nThe answers to your self assessment questions are below. <br/><br/>";
        for (var index = 0; index < this.Questions.length; index++) {
            var answer = 'No Answer Given';
            if (this.Questions[index].Answer != undefined) {
                answer = this.Questions[index].Answer;
            }
            mailbody += "<b>" + this.Questions[index].Question + "</b><br>" + answer + "<br><br>";
        }
        //console.log(mailbody);
        email.compose({
            subject: "SAFE Alternatives Self Assessment",
            body: mailbody
        }).then(function () {
            //console.log("Email composer closed");
        }, function (err) {
            console.log("Error: " + err);
        });
    };
    SelfAssessComponent = __decorate([
        core_1.Component({
            selector: 'SelfAssess',
            templateUrl: './pages/SelfAssess/SelfAssess.component.html',
            styleUrls: ['./pages/SelfAssess/SelfAssess.component.css']
        }),
        __metadata("design:paramtypes", [data_service_1.DataService])
    ], SelfAssessComponent);
    return SelfAssessComponent;
}());
exports.SelfAssessComponent = SelfAssessComponent;
