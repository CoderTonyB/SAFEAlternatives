export class LogResponse {
    LogResponseId: number;
    LogId: number;
    QuestionId: number;
    Answer: string;
}