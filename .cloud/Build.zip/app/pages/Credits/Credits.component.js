"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var utils = require("utils/utils");
var page_1 = require("tns-core-modules/ui/page/page");
var dialogs_1 = require("nativescript-angular/directives/dialogs");
//import { RouterExtensions } from 'nativescript-angular';
//import { TextField } from 'ui/text-field';
//import { EventData } from 'data/observable';
//import { ActivatedRoute } from '@angular/router';
var CreditsComponent = (function () {
    function CreditsComponent(page, params) {
        this.page = page;
        this.params = params;
    }
    CreditsComponent.prototype.ngOnInit = function () { };
    CreditsComponent.prototype.GoToGit = function () {
        utils.openUrl("https://github.com/CoderTonyB/SAFEAlternatives");
    };
    CreditsComponent.prototype.closeCredits = function () {
        this.params.closeCallback();
    };
    CreditsComponent = __decorate([
        core_1.Component({
            selector: 'Credits',
            templateUrl: './pages/Credits/Credits.component.html',
            styleUrls: ['./pages/Credits/Credits.component.css']
        }),
        __metadata("design:paramtypes", [page_1.Page, dialogs_1.ModalDialogParams])
    ], CreditsComponent);
    return CreditsComponent;
}());
exports.CreditsComponent = CreditsComponent;
