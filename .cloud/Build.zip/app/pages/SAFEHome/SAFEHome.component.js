"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var Credits_component_1 = require("../../pages/Credits/Credits.component");
var modal_dialog_1 = require("nativescript-angular/modal-dialog");
var utils = require("utils/utils");
var SAFEHomeComponent = (function () {
    function SAFEHomeComponent(modalService, vcRef) {
        this.modalService = modalService;
        this.vcRef = vcRef;
    }
    SAFEHomeComponent.prototype.ngOnInit = function () { };
    SAFEHomeComponent.prototype.openCredits = function () {
        var today = new Date();
        var options = {
            viewContainerRef: this.vcRef,
            context: "",
            fullscreen: false,
        };
        return this.modalService.showModal(Credits_component_1.CreditsComponent, options);
    };
    SAFEHomeComponent.prototype.visitURL = function (url) {
        switch (url) {
            case 'SAFE':
                utils.openUrl("http://www.selfinjury.com");
                break;
            case 'FACEBOOK':
                utils.openUrl("https://www.facebook.com/SAFE-Self-Abuse-Finally-Ends-ALTERNATIVES-100545512550/");
                break;
            case 'TWITTER':
                utils.openUrl("https://twitter.com/theSAFEstore");
                break;
            case 'YOUTUBE':
                utils.openUrl("https://www.youtube.com/watch?v=3ez5tZ27HUo");
                break;
            default:
                break;
        }
    };
    SAFEHomeComponent.prototype.callDontCut = function (event) {
        var phone = require("nativescript-phone");
        phone.dial("1-800-366-8288", true);
        console.log(event.eventName);
    };
    SAFEHomeComponent = __decorate([
        core_1.Component({
            selector: 'SAFEHome',
            providers: [modal_dialog_1.ModalDialogService],
            templateUrl: './pages/SAFEHome/SAFEHome.component.html',
            styleUrls: ['./pages/SAFEHome/SAFEHome.component.css']
        }),
        __metadata("design:paramtypes", [modal_dialog_1.ModalDialogService,
            core_1.ViewContainerRef])
    ], SAFEHomeComponent);
    return SAFEHomeComponent;
}());
exports.SAFEHomeComponent = SAFEHomeComponent;
