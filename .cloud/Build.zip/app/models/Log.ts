export class Log {
    LogId: number;
    TimestampUTC: string;
    LogTypeId: number;
    Title: string
}