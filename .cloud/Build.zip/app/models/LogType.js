"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var LogType = (function () {
    function LogType() {
    }
    return LogType;
}());
exports.LogType = LogType;
