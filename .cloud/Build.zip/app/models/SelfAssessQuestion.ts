export class SelfAssessQuestion {
    QuestionId: number;
    Question: string;
    Order: number;
    Type: string;
    Answer: any;
}