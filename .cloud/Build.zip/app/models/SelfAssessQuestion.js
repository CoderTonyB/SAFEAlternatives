"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var SelfAssessQuestion = (function () {
    function SelfAssessQuestion() {
    }
    return SelfAssessQuestion;
}());
exports.SelfAssessQuestion = SelfAssessQuestion;
