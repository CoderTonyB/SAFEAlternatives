export class Item {
    id: number;
    name: string;
    role: string;
}
