"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var nativescript_module_1 = require("nativescript-angular/nativescript.module");
var nativescript_angular_1 = require("nativescript-angular");
var app_routing_1 = require("./app.routing");
var app_component_1 = require("./app.component");
var modal_dialog_1 = require("nativescript-angular/modal-dialog");
var item_service_1 = require("./item/item.service");
var items_component_1 = require("./item/items.component");
var item_detail_component_1 = require("./item/item-detail.component");
var home_component_1 = require("./pages/home/home.component");
var SAFEHome_component_1 = require("./pages/SAFEHome/SAFEHome.component");
var LogHome_component_1 = require("./pages/LogHome/LogHome.component");
var LogList_component_1 = require("./pages/LogList/LogList.component");
var LogInventory_component_1 = require("./pages/LogInventory/LogInventory.component");
var LogDataEntry_component_1 = require("./pages/LogDataEntry/LogDataEntry.component");
var SelfAssess_component_1 = require("./pages/SelfAssess/SelfAssess.component");
var Credits_component_1 = require("./pages/Credits/Credits.component");
var data_service_1 = require("./services/data.service");
var state_service_1 = require("./services/state.service");
// Uncomment and add to NgModule imports if you need to use two-way binding
var forms_1 = require("nativescript-angular/forms");
// Uncomment and add to NgModule imports  if you need to use the HTTP wrapper
// import { NativeScriptHttpModule } from "nativescript-angular/http";
var AppModule = (function () {
    /*
    Pass your application module to the bootstrapModule function located in main.ts to start your app
    */
    function AppModule() {
    }
    AppModule = __decorate([
        core_1.NgModule({
            bootstrap: [
                app_component_1.AppComponent
            ],
            imports: [
                nativescript_module_1.NativeScriptModule,
                app_routing_1.AppRoutingModule,
                nativescript_angular_1.NativeScriptRouterModule,
                forms_1.NativeScriptFormsModule
            ],
            declarations: [
                app_component_1.AppComponent,
                items_component_1.ItemsComponent,
                item_detail_component_1.ItemDetailComponent,
                home_component_1.HomeComponent,
                SAFEHome_component_1.SAFEHomeComponent,
                LogHome_component_1.LogHomeComponent,
                LogList_component_1.LogListComponent,
                LogInventory_component_1.LogInventoryComponent,
                LogDataEntry_component_1.LogDataEntryComponent,
                SelfAssess_component_1.SelfAssessComponent,
                Credits_component_1.CreditsComponent
            ],
            providers: [
                item_service_1.ItemService, data_service_1.DataService, state_service_1.StateService, modal_dialog_1.ModalDialogService
            ],
            schemas: [
                core_1.NO_ERRORS_SCHEMA
            ],
            entryComponents: [
                Credits_component_1.CreditsComponent
            ]
        })
        /*
        Pass your application module to the bootstrapModule function located in main.ts to start your app
        */
    ], AppModule);
    return AppModule;
}());
exports.AppModule = AppModule;
