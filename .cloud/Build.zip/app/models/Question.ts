export class Question {
    QuestionId: number;
    Question: string;
    Hint: string;
    Required: number;
    LogTypeId: number;
    QuestionOrder: number;
}