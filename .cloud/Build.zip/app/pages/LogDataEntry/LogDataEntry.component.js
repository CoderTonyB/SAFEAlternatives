"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var LogResponse_1 = require("./../../models/LogResponse");
var core_1 = require("@angular/core");
var nativescript_angular_1 = require("nativescript-angular");
//import { TextField } from 'ui/text-field';
//import { EventData } from 'data/observable';
var router_1 = require("@angular/router");
var data_service_1 = require("../../services/data.service");
var Log_1 = require("../../models/Log");
var email = require("nativescript-email");
var LogDataEntryComponent = (function () {
    function LogDataEntryComponent(route, dataService, router) {
        this.route = route;
        this.dataService = dataService;
        this.router = router;
        this.LogResponses = new Array();
        this.LogPrototype = new Log_1.Log();
    }
    LogDataEntryComponent.prototype.ngOnInit = function () {
        var _this = this;
        var id = this.route.snapshot.params["id"];
        var title = this.route.snapshot.params["title"];
        if (id > 0) {
            this.LogPrototype.LogId = id;
            this.dataService.getLogTypeForLog(id).then(function (logType) {
                _this.LogPrototype.LogTypeId = logType.LogTypeId;
                _this.LogPrototype.Title = title;
                _this.LoadQuestions(logType.LogTypeId).then(function (questions) {
                    _this.Questions = questions;
                    //this.LoadAnswers(id);
                    _this.dataService.getLogResponses(id).then(function (logResponses) {
                        _this.LogResponses = logResponses;
                    });
                });
            });
        }
        else {
            this.LogPrototype.LogTypeId = -id; //we passed the type as a negative integer since there was no ID
            this.LogPrototype.LogId = -1; //flag as new
            this.LogPrototype.Title = title;
            this.LoadQuestions(-id).then(function (questions) { return _this.Questions = questions; });
        }
    };
    LogDataEntryComponent.prototype.getAnswerIndex = function (QuestionId) {
        var index = this.LogResponses.findIndex(function (x) { return x.QuestionId == QuestionId; });
        if (index == -1) {
            var logResponse = new LogResponse_1.LogResponse();
            logResponse.Answer = "";
            logResponse.LogId = this.LogPrototype.LogId;
            logResponse.QuestionId = QuestionId;
            return this.LogResponses.push(logResponse) - 1;
        }
        else {
            return index;
        }
    };
    LogDataEntryComponent.prototype.LoadQuestions = function (id) {
        return this.dataService.getQuestionsForLogType(id);
    };
    LogDataEntryComponent.prototype.emailLog = function () {
        var mailbody = "";
        for (var index = 0; index < this.Questions.length; index++) {
            mailbody += "<b>" + this.Questions[index].Question + "</b><br>" + this.LogResponses[this.getAnswerIndex(this.Questions[index].QuestionId)].Answer + "<br><br>";
        }
        console.log(mailbody);
        email.compose({
            subject: this.LogPrototype.Title,
            body: mailbody,
            to: ['']
        }).then(function () {
            console.log("Email composer closed");
        }, function (err) {
            console.log("Error: " + err);
        });
    };
    LogDataEntryComponent.prototype.Save = function () {
        var _this = this;
        if (this.LogPrototype.LogId == -1) {
            this.dataService.AddLog(this.LogPrototype).then(function (result) {
                _this.LogPrototype.LogId = result;
                _this.dataService.saveLogResponses(_this.LogResponses, _this.LogPrototype).then(function (result) {
                    if (result == true) {
                        _this.router.back();
                    }
                });
            });
        }
        else {
            this.dataService.saveLogResponses(this.LogResponses, this.LogPrototype).then(function (result) {
                if (result == true) {
                    _this.router.back();
                }
            });
        }
    };
    LogDataEntryComponent = __decorate([
        core_1.Component({
            selector: 'LogDataEntry',
            templateUrl: './pages/LogDataEntry/LogDataEntry.component.html',
            styleUrls: ['./pages/LogDataEntry/LogDataEntry.component.css']
        }),
        __metadata("design:paramtypes", [router_1.ActivatedRoute, data_service_1.DataService, nativescript_angular_1.RouterExtensions])
    ], LogDataEntryComponent);
    return LogDataEntryComponent;
}());
exports.LogDataEntryComponent = LogDataEntryComponent;
