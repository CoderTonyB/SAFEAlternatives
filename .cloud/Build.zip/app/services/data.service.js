"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var Sqlite = require("nativescript-sqlite");
var Log_1 = require("../models/Log");
var LogType_1 = require("../models/LogType");
var Question_1 = require("../models/Question");
var LogResponse_1 = require("../models/LogResponse");
var SelfAssessQuestion_1 = require("../models/SelfAssessQuestion");
var DataService = (function () {
    function DataService() {
        this.initDatabase();
    }
    DataService.prototype.initDatabase = function () {
        var _this = this;
        if (this.database == undefined) {
            if (!Sqlite.exists("SAFE.db")) {
                Sqlite.copyDatabase("SAFE.db");
                console.log("Initial database created");
            }
            new Sqlite("SAFE.db").then(function (db) {
                _this.database = db;
            }, function (error) {
                console.log("OPEN DB ERROR", error);
            });
            console.log("Database is initialized");
        }
    };
    DataService.prototype.logError = function (error) {
        console.log(error);
    };
    DataService.prototype.AddLog = function (log) {
        var _this = this;
        var date = new Date();
        var newID = -1;
        var sql = "INSERT INTO Logs (TimestampUTC, Title, LogTypeId) VALUES (?,?,?)";
        return new Promise(function (resolve, reject) {
            if (!log.Title) {
                log.Title = "Untitled";
            }
            _this.database.execSQL(sql, [date.toISOString(), log.Title, log.LogTypeId]).then(function (response) {
                console.log("Save new log Response:", response);
                newID = response;
                resolve(response);
            }, function (err) {
                _this.logError(err);
                reject(err);
            });
        });
    };
    DataService.prototype.saveLogResponses = function (logResponses, log) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            logResponses.forEach(function (logResponse) {
                if (logResponse.LogResponseId != null) {
                    var sql = "UPDATE LogResponses set Answer = ? where LogResponseId = ?";
                    _this.database.execSQL(sql, [logResponse.Answer, logResponse.LogResponseId]).then(function (response) {
                        console.log("Save Response:", response);
                    }, function (err) {
                        _this.logError(err);
                        resolve(false);
                    });
                }
                else {
                    var sql = "INSERT INTO LogResponses (LogId, QuestionId, Answer) VALUES (?,?,?)";
                    _this.database.execSQL(sql, [log.LogId, logResponse.QuestionId, logResponse.Answer]).then(function (response) {
                        console.log("Save Response:", response);
                    }, function (err) {
                        _this.logError(err);
                        resolve(false);
                    });
                }
            });
            resolve(true);
        });
    };
    DataService.prototype.getLogInventory = function (LogTypeId) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            var logs = new Array();
            _this.database.all("SELECT LogId, TimestampUTC, Title, LogTypeId FROM Logs where LogTypeId = ? order by TimestampUTC Desc", [LogTypeId]).then(function (rows) {
                rows.forEach(function (row) {
                    var log = new Log_1.Log();
                    log.LogId = row[0];
                    log.TimestampUTC = new Date(row[1]).toLocaleString();
                    log.Title = row[2];
                    log.LogTypeId = row[3];
                    logs.push(log);
                });
                resolve(logs);
            }, function (error) {
                console.log("SELECT ERROR", error);
                reject(error);
            });
        });
    };
    DataService.prototype.getLogTypeForLog = function (LogId) {
        var _this = this;
        var result = new Promise(function (resolve, reject) {
            _this.database.get("SELECT Logs.LogTypeId, LogType, Description from Logs inner join LogTypes on LogTypes.LogTypeId = Logs.LogTypeId where LogId = ?", LogId).then(function (row) {
                var logType = new LogType_1.LogType();
                logType.LogTypeId = row[0];
                logType.LogType = row[1];
                logType.Description = row[2];
                resolve(logType);
            }, function (error) {
                console.log("SELECT ERROR", error);
                return error;
            });
        });
        return result;
    };
    DataService.prototype.getLogTypeById = function (id) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            var LogTypes = new Array();
            _this.database.all("SELECT LogTypeId, LogType, Description FROM LogTypes where LogTypeId = ?", id).then(function (rows) {
                var logType = new LogType_1.LogType();
                logType.LogTypeId = rows[0][0];
                logType.LogType = rows[0][1];
                logType.Description = rows[0][2];
                resolve(logType);
            }, function (error) {
                console.log("SELECT ERROR", error);
                reject(error);
            });
        });
    };
    DataService.prototype.getLogTypes = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            var LogTypes = new Array();
            _this.database.all("SELECT LogTypeId, LogType FROM LogTypes order by LogTypeId").then(function (rows) {
                rows.forEach(function (row) {
                    var logType = new LogType_1.LogType();
                    logType.LogTypeId = row[0];
                    logType.LogType = row[1];
                    LogTypes.push(logType);
                });
                resolve(LogTypes);
            }, function (error) {
                console.log("SELECT ERROR", error);
                reject(error);
            });
        });
    };
    DataService.prototype.getSelfAssessmentQuestions = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            var Questions = new Array();
            _this.database.all("SELECT QuestionId, [Order], Question, Type, Answer from SelfAssessment order by [Order]").then(function (rows) {
                rows.forEach(function (row) {
                    var Question = new SelfAssessQuestion_1.SelfAssessQuestion();
                    Question.QuestionId = row[0];
                    Question.Order = row[1];
                    Question.Question = row[2];
                    Question.Type = row[3];
                    switch (Question.Type) {
                        case 'True/False':
                            if (row[3].toLowerCase() == 'true') {
                                Question.Answer = true;
                            }
                            else {
                                Question.Answer = false;
                            }
                            break;
                        case 'Date':
                            //Question.Answer = new Date(Date.now());
                            //console.log("current date answer:", Question.Answer);
                            break;
                        default:
                            Question.Answer = row[4];
                            break;
                    }
                    Questions.push(Question);
                });
                resolve(Questions);
            }, function (error) {
                console.log("SELECT ERROR", error);
                reject(error);
            });
        });
    };
    DataService.prototype.getLogResponses = function (LogId) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            var LogResponses = new Array();
            _this.database.all("Select LogResponseId, LogId, QuestionId, Answer from LogResponses\n                            where LogId = ?", [LogId]).then(function (rows) {
                rows.forEach(function (row) {
                    var logResponse = new LogResponse_1.LogResponse();
                    logResponse.LogResponseId = row[0];
                    logResponse.LogId = row[1];
                    logResponse.QuestionId = row[2];
                    logResponse.Answer = row[3];
                    LogResponses.push(logResponse);
                });
                resolve(LogResponses);
            }, function (error) {
                console.log("SELECT ERROR", error);
                reject(error);
            });
        });
    };
    DataService.prototype.getQuestionsForLogType = function (LogTypeId) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            var Questions = new Array();
            _this.database.all("Select QuestionId, Question, Hint, Required, LogTypeId, QuestionOrder from Questions \n                where LogTypeId = ? \n                order by QuestionOrder", [LogTypeId]).then(function (rows) {
                rows.forEach(function (row) {
                    var question = new Question_1.Question();
                    question.QuestionId = row[0];
                    question.Question = row[1];
                    question.Hint = row[2];
                    question.Required = row[3];
                    question.LogTypeId = row[4];
                    Questions.push(question);
                });
                resolve(Questions);
            }, function (error) {
                console.log("SELECT ERROR", error);
                reject(error);
            });
        });
    };
    DataService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [])
    ], DataService);
    return DataService;
}());
exports.DataService = DataService;
