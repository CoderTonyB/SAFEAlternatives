"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var nativescript_angular_1 = require("nativescript-angular");
var application_1 = require("application");
var platform_1 = require("platform");
var application = require("application");
var state_service_1 = require("../../services/state.service");
var HomeComponent = (function () {
    function HomeComponent(routerExtensions, stateService) {
        this.routerExtensions = routerExtensions;
        this.stateService = stateService;
    }
    HomeComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (!platform_1.isAndroid) {
            return;
        }
        application.android.on(application_1.AndroidApplication.activityBackPressedEvent, function (data) {
            data.cancel = true;
            _this.routerExtensions.back();
        });
    };
    HomeComponent.prototype.selectTab = function (event) {
        this.stateService.setShowback(event.newIndex == 1); //if we're on the second (log tab), show the back button
    };
    HomeComponent = __decorate([
        core_1.Component({
            selector: 'home',
            templateUrl: './pages/home/home.component.html',
            styleUrls: ['./pages/home/home.component.css']
        }),
        __metadata("design:paramtypes", [nativescript_angular_1.RouterExtensions,
            state_service_1.StateService])
    ], HomeComponent);
    return HomeComponent;
}());
exports.HomeComponent = HomeComponent;
