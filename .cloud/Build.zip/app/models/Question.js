"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Question = (function () {
    function Question() {
    }
    return Question;
}());
exports.Question = Question;
