"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Log = (function () {
    function Log() {
    }
    return Log;
}());
exports.Log = Log;
