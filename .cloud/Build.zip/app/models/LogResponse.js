"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var LogResponse = (function () {
    function LogResponse() {
    }
    return LogResponse;
}());
exports.LogResponse = LogResponse;
