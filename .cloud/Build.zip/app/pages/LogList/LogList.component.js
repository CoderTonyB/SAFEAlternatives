"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var nativescript_angular_1 = require("nativescript-angular");
var data_service_1 = require("../../services/data.service");
var state_service_1 = require("../../services/state.service");
var utils = require("utils/utils");
var LogListComponent = (function () {
    function LogListComponent(routerExtensions, dataService, stateService) {
        this.routerExtensions = routerExtensions;
        this.dataService = dataService;
        this.stateService = stateService;
    }
    LogListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.stateService.setShowback(false);
        this.dataService.getLogTypes().then(function (logs) {
            _this.logs = logs;
        }, function (error) { return alert("Error:" + error); });
    };
    LogListComponent.prototype.visitURL = function (url) {
        utils.openUrl("https://www.youtube.com/channel/UC-dh1cEUaK6D_vK0cUVCiFQ");
    };
    LogListComponent.prototype.OpenLogList = function (LogId) {
        this.routerExtensions.navigate(['/home', { outlets: { logoutlet: ['loginventory', LogId] } }]);
    };
    LogListComponent = __decorate([
        core_1.Component({
            selector: 'LogList',
            templateUrl: './pages/LogList/LogList.component.html',
            styleUrls: ['./pages/LogList/LogList.component.css']
        }),
        __metadata("design:paramtypes", [nativescript_angular_1.RouterExtensions,
            data_service_1.DataService, state_service_1.StateService])
    ], LogListComponent);
    return LogListComponent;
}());
exports.LogListComponent = LogListComponent;
