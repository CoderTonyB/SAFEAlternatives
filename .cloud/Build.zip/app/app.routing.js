"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("nativescript-angular/router");
var items_component_1 = require("./item/items.component");
var item_detail_component_1 = require("./item/item-detail.component");
var home_component_1 = require("./pages/home/home.component");
var SAFEHome_component_1 = require("./pages/SAFEHome/SAFEHome.component");
var LogHome_component_1 = require("./pages/LogHome/LogHome.component");
var LogList_component_1 = require("./pages/LogList/LogList.component");
var LogInventory_component_1 = require("./pages/LogInventory/LogInventory.component");
var LogDataEntry_component_1 = require("./pages/LogDataEntry/LogDataEntry.component");
var SelfAssess_component_1 = require("./pages/SelfAssess/SelfAssess.component");
var routes = [
    { path: "", redirectTo: "/home/(homeoutlet:safehome//logoutlet:loghome//assessoutlet:assesshome)", pathMatch: "full" },
    {
        path: "home", component: home_component_1.HomeComponent,
        children: [
            { path: "safehome", component: SAFEHome_component_1.SAFEHomeComponent, outlet: 'homeoutlet' },
            { path: "loghome", component: LogHome_component_1.LogHomeComponent, outlet: 'logoutlet' },
            { path: "loglist", component: LogList_component_1.LogListComponent, outlet: 'logoutlet' },
            { path: "loginventory/:id", component: LogInventory_component_1.LogInventoryComponent, outlet: 'logoutlet' },
            { path: "logdataentry/:id/:title", component: LogDataEntry_component_1.LogDataEntryComponent, outlet: 'logoutlet' },
            { path: "assesshome", component: SelfAssess_component_1.SelfAssessComponent, outlet: 'assessoutlet' }
        ]
    },
    { path: "items", component: items_component_1.ItemsComponent },
    { path: "item/:id", component: item_detail_component_1.ItemDetailComponent },
];
var AppRoutingModule = (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = __decorate([
        core_1.NgModule({
            imports: [router_1.NativeScriptRouterModule.forRoot(routes)],
            exports: [router_1.NativeScriptRouterModule]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());
exports.AppRoutingModule = AppRoutingModule;
