"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var page_1 = require("ui/page");
var nativescript_angular_1 = require("nativescript-angular");
var data_service_1 = require("../../services/data.service");
var state_service_1 = require("../../services/state.service");
var LogHomeComponent = (function () {
    function LogHomeComponent(page, routerExtensions, dataService, stateService) {
        this.page = page;
        this.routerExtensions = routerExtensions;
        this.dataService = dataService;
        this.stateService = stateService;
    }
    LogHomeComponent.prototype.ngOnInit = function () {
        //bypass password entry as they are already logged into their phone
        this.stateService.setShowback(true);
        this.routerExtensions.navigate(['/home', {
                outlets: { logoutlet: ['loglist'] }
            }]);
        //end bypass password entry
        this.txtPassword = this.page.getViewById("txtPassword");
        this.txtPassword2 = this.page.getViewById("txtPassword2");
        this.txtPassword.focus();
        this.stateService.setShowback(false);
    };
    LogHomeComponent.prototype.savePassword = function (event) {
        if (this.txtPassword.text.length < 4) {
            alert('Please enter at least 4 characters for your password');
            return;
        }
        if (this.txtPassword.text != this.txtPassword2.text) {
            alert("Passwords do not match!");
        }
        else {
            this.stateService.setShowback(true);
            this.routerExtensions.navigate(['/home', {
                    outlets: { logoutlet: ['loglist'] }
                }]);
        }
    };
    LogHomeComponent = __decorate([
        core_1.Component({
            selector: 'LogHome',
            templateUrl: './pages/LogHome/LogHome.component.html',
            styleUrls: ['./pages/LogHome/LogHome.component.css']
        }),
        __metadata("design:paramtypes", [page_1.Page,
            nativescript_angular_1.RouterExtensions,
            data_service_1.DataService,
            state_service_1.StateService])
    ], LogHomeComponent);
    return LogHomeComponent;
}());
exports.LogHomeComponent = LogHomeComponent;
