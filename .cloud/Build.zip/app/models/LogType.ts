export class LogType {
    LogTypeId: number;
    LogType: string;
    Description: string;
}