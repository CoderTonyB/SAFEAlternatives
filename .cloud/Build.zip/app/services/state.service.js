"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
//var Sqlite = require("nativescript-sqlite");
var BehaviorSubject_1 = require("rxjs/BehaviorSubject");
var StateService = (function () {
    function StateService() {
        this.showBack = new BehaviorSubject_1.BehaviorSubject(false);
    }
    StateService.prototype.setShowback = function (showBack) {
        this.showBack.next(showBack);
    };
    StateService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [])
    ], StateService);
    return StateService;
}());
exports.StateService = StateService;
