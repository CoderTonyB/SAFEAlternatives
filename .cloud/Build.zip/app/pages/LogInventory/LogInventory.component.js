"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var nativescript_angular_1 = require("nativescript-angular");
//import { TextField } from 'ui/text-field';
//import { EventData } from 'data/observable';
var router_1 = require("@angular/router");
var data_service_1 = require("../../services/data.service");
var LogType_1 = require("../../models/LogType");
var dialogs = require("ui/dialogs");
var state_service_1 = require("../../services/state.service");
var LogInventoryComponent = (function () {
    function LogInventoryComponent(route, dataService, routerExtensions, stateService) {
        var _this = this;
        this.route = route;
        this.dataService = dataService;
        this.routerExtensions = routerExtensions;
        this.stateService = stateService;
        this.logtype = new LogType_1.LogType();
        this.logs = new Array();
        var id = this.route.snapshot.params["id"];
        this.stateService.setShowback(true);
        this.dataService.getLogInventory(id).then(function (x) {
            _this.logs = x;
        }, function (err) { return console.dir(err); });
        this.dataService.getLogTypeById(parseInt(id)).then(function (logType) {
            _this.logtype = logType;
            console.log("type:", _this.logtype.LogType);
        });
    }
    LogInventoryComponent.prototype.newLog = function () {
        var _this = this;
        dialogs.prompt({
            title: "New Log",
            message: "Please enter a title for your new log",
            okButtonText: "Save",
            cancelButtonText: "Cancel",
            defaultText: "",
            inputType: dialogs.inputType.text
        }).then(function (result) {
            if (result.result) {
                _this.OpenLogDataEntry(_this.logtype.LogTypeId * -1, result.text); //sending negitive to indicate new
            }
        });
    };
    LogInventoryComponent.prototype.OpenLogDataEntry = function (LogId, Title) {
        if (Title === void 0) { Title = ""; }
        console.log("open log:", LogId, " title:", Title);
        this.routerExtensions.navigate(['/home', { outlets: { logoutlet: ['logdataentry', LogId, Title] } }]);
    };
    LogInventoryComponent.prototype.ngOnInit = function () { };
    LogInventoryComponent = __decorate([
        core_1.Component({
            selector: 'LogInventory',
            templateUrl: './pages/LogInventory/LogInventory.component.html',
            styleUrls: ['./pages/LogInventory/LogInventory.component.css']
        }),
        __metadata("design:paramtypes", [router_1.ActivatedRoute, data_service_1.DataService,
            nativescript_angular_1.RouterExtensions, state_service_1.StateService])
    ], LogInventoryComponent);
    return LogInventoryComponent;
}());
exports.LogInventoryComponent = LogInventoryComponent;
