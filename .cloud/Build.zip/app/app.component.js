"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var nativescript_angular_1 = require("nativescript-angular");
var state_service_1 = require("../app/services/state.service");
var AppComponent = (function () {
    function AppComponent(routerExtensions, stateService) {
        var _this = this;
        this.routerExtensions = routerExtensions;
        this.stateService = stateService;
        this.showBack = false;
        this.stateService.showBack.subscribe(function (showBack) { return _this.showBack = showBack; });
    }
    AppComponent.prototype.goBack = function () {
        this.routerExtensions.back();
    };
    AppComponent.prototype.ngOnInit = function () {
        //this.showBack = !isAndroid;
    };
    AppComponent = __decorate([
        core_1.Component({
            selector: "ns-app",
            templateUrl: "app.component.html",
        }),
        __metadata("design:paramtypes", [nativescript_angular_1.RouterExtensions, state_service_1.StateService])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
